﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;

namespace UcakRezervasyonSistemi
{
    public partial class MusteriPanel : Form
    {
        private Musteri musteri;
        private RezervasyonServisi rezervasyonServisi;

        // Kontroller
        private Label lblBaslik;
        private Label lblHosgeldin;
        private Panel pnlMenu;
        private Button btnUcusAra;
        private Button btnRezervasyonlarim;
        private Button btnProfilim;
        private Button btnCikis;
        private Panel pnlBilgi;
        private Label lblBilgiBaslik;
        private Label lblBilgiDetay;

        public MusteriPanel(Musteri musteri)
        {
            InitializeComponent();
            this.musteri = musteri;
            rezervasyonServisi = new RezervasyonServisi();

            // Form ayarları
            this.Text = "Müşteri Paneli";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.WhiteSmoke;

            KontrolleriOlustur();
            BilgileriGuncelle();
        }

        private void KontrolleriOlustur()
        {
            // Başlık
            lblBaslik = new Label
            {
                Text = "MÜŞTERİ PANELİ",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(230, 20),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            this.Controls.Add(lblBaslik);

            // Hoşgeldin mesajı
            lblHosgeldin = new Label
            {
                Text = $"Hoş geldiniz, {musteri.GetTamIsim()}",
                Font = new Font("Arial", 12, FontStyle.Regular),
                Location = new Point(30, 70),
                AutoSize = true,
                ForeColor = Color.DarkGreen
            };
            this.Controls.Add(lblHosgeldin);

            // Menu Paneli
            pnlMenu = new Panel
            {
                Location = new Point(30, 110),
                Size = new Size(640, 120),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.Add(pnlMenu);

            // Uçuş Ara Butonu
            btnUcusAra = new Button
            {
                Text = "🔍 Uçuş Ara",
                Location = new Point(20, 30),
                Size = new Size(140, 60),
                BackColor = Color.LightSkyBlue,
                Font = new Font("Arial", 11, FontStyle.Bold),
                Cursor = Cursors.Hand,
                FlatStyle = FlatStyle.Flat
            };
            btnUcusAra.Click += BtnUcusAra_Click;
            pnlMenu.Controls.Add(btnUcusAra);

            // Rezervasyonlarım Butonu
            btnRezervasyonlarim = new Button
            {
                Text = "📋 Rezervasyonlarım",
                Location = new Point(180, 30),
                Size = new Size(140, 60),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 11, FontStyle.Bold),
                Cursor = Cursors.Hand,
                FlatStyle = FlatStyle.Flat
            };
            btnRezervasyonlarim.Click += BtnRezervasyonlarim_Click;
            pnlMenu.Controls.Add(btnRezervasyonlarim);

            // Profilim Butonu
            btnProfilim = new Button
            {
                Text = "👤 Profilim",
                Location = new Point(340, 30),
                Size = new Size(140, 60),
                BackColor = Color.LightYellow,
                Font = new Font("Arial", 11, FontStyle.Bold),
                Cursor = Cursors.Hand,
                FlatStyle = FlatStyle.Flat
            };
            btnProfilim.Click += BtnProfilim_Click;
            pnlMenu.Controls.Add(btnProfilim);

            // Çıkış Butonu
            btnCikis = new Button
            {
                Text = "🚪 Çıkış",
                Location = new Point(500, 30),
                Size = new Size(120, 60),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 11, FontStyle.Bold),
                Cursor = Cursors.Hand,
                FlatStyle = FlatStyle.Flat
            };
            btnCikis.Click += BtnCikis_Click;
            pnlMenu.Controls.Add(btnCikis);

            // Bilgi Paneli
            pnlBilgi = new Panel
            {
                Location = new Point(30, 250),
                Size = new Size(640, 200),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.Add(pnlBilgi);

            // Bilgi Başlık
            lblBilgiBaslik = new Label
            {
                Text = "Rezervasyon Özeti",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 15),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            pnlBilgi.Controls.Add(lblBilgiBaslik);

            // Bilgi Detay
            lblBilgiDetay = new Label
            {
                Text = "Yükleniyor...",
                Font = new Font("Arial", 11),
                Location = new Point(20, 50),
                Size = new Size(600, 130),
                ForeColor = Color.Black
            };
            pnlBilgi.Controls.Add(lblBilgiDetay);
        }

        // Bilgileri güncelle
        private void BilgileriGuncelle()
        {
            var rezervasyonlar = rezervasyonServisi.GetMusteriAktifRezervasyonlari(musteri.Id);
            var tumRezervasyonlar = rezervasyonServisi.GetMusteriRezervasyonlari(musteri.Id);

            string bilgi = $"Toplam Rezervasyon: {tumRezervasyonlar.Count}\n";
            bilgi += $"Aktif Rezervasyon: {rezervasyonlar.Count}\n";
            bilgi += $"İptal Edilen: {tumRezervasyonlar.Count - rezervasyonlar.Count}\n\n";

            if (rezervasyonlar.Count > 0)
            {
                bilgi += "─────────────────────────────────\n";
                bilgi += "Yaklaşan Uçuşlar:\n";
                bilgi += "─────────────────────────────────\n";

                foreach (var rez in rezervasyonlar)
                {
                    if (rez.Ucus.KalkisTarihi >= DateTime.Today)
                    {
                        bilgi += $"• {rez.Ucus.UcusNo}: {rez.Ucus.KalkisYeri} → {rez.Ucus.VarisYeri}\n";
                        bilgi += $"  Tarih: {rez.Ucus.KalkisTarihi:dd.MM.yyyy} {rez.Ucus.KalkisSaati}\n";
                        bilgi += $"  Koltuk: {rez.Koltuk.KoltukNo}\n\n";
                    }
                }
            }
            else
            {
                bilgi += "\nHenüz aktif rezervasyonunuz bulunmamaktadır.\n";
                bilgi += "Uçuş aramaya başlamak için 'Uçuş Ara' butonuna tıklayın!";
            }

            lblBilgiDetay.Text = bilgi;
        }

        // Uçuş Ara butonu
        private void BtnUcusAra_Click(object sender, EventArgs e)
        {
            UcusAramaForm ucusAramaForm = new UcusAramaForm(musteri);
            ucusAramaForm.ShowDialog();
            BilgileriGuncelle(); // Form kapandığında bilgileri yenile
        }

        // Rezervasyonlarım butonu
        private void BtnRezervasyonlarim_Click(object sender, EventArgs e)
        {
            var rezervasyonlar = rezervasyonServisi.GetMusteriRezervasyonlari(musteri.Id);

            if (rezervasyonlar.Count == 0)
            {
                MessageBox.Show("Henüz rezervasyonunuz bulunmamaktadır.", "Bilgi",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string mesaj = "REZERVASYONLARIM\n";
            mesaj += "══════════════════════════════════\n\n";

            foreach (var rez in rezervasyonlar)
            {
                mesaj += $"Rezervasyon No: {rez.RezervasyonNo}\n";
                mesaj += $"Uçuş: {rez.Ucus.UcusNo} ({rez.Ucus.KalkisYeri} → {rez.Ucus.VarisYeri})\n";
                mesaj += $"Tarih: {rez.Ucus.KalkisTarihi:dd.MM.yyyy} {rez.Ucus.KalkisSaati}\n";
                mesaj += $"Koltuk: {rez.Koltuk.KoltukNo} ({rez.Koltuk.Tip})\n";
                mesaj += $"Fiyat: {rez.ToplamFiyat:C}\n";
                mesaj += $"Durum: {rez.Durum}\n";
                mesaj += "─────────────────────────────────\n\n";
            }

            MessageBox.Show(mesaj, "Rezervasyonlarım",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Profilim butonu
        private void BtnProfilim_Click(object sender, EventArgs e)
        {
            string profil = "PROFİL BİLGİLERİ\n";
            profil += "══════════════════════════════════\n\n";
            profil += $"Ad Soyad: {musteri.GetTamIsim()}\n";
            profil += $"TC No: {musteri.TcNo}\n";
            profil += $"Email: {musteri.Email}\n";
            profil += $"Telefon: {musteri.TelefonNo}\n";
            profil += $"Kayıt Tarihi: {musteri.KayitTarihi:dd.MM.yyyy}\n";

            MessageBox.Show(profil, "Profil Bilgilerim",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Çıkış butonu
        private void BtnCikis_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Çıkış yapmak istediğinize emin misiniz?", "Çıkış",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }
        }

        // Form kapanınca uygulamayı kapat
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit();
            }
        }

        private void MusteriPanel_Load(object sender, EventArgs e)
        {

        }
    }
}