﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Models
{
    // Admin sınıfı - Kullanıcı sınıfından türetilmiş
    public class Admin : Kullanici
    {
        // Admin'e özel özellikler
        public string YetkiSeviyesi { get; set; }

        // Constructor
        public Admin()
        {
            Rol = KullaniciRolu.Admin;
            YetkiSeviyesi = "Yönetici";
        }

        public Admin(int id, string ad, string soyad, string email, string sifre,
                     string telefonNo, string yetkiSeviyesi)
            : base(id, ad, soyad, email, sifre, telefonNo)
        {
            Rol = KullaniciRolu.Admin;
            YetkiSeviyesi = yetkiSeviyesi;
        }

        // Abstract metodun implementasyonu
        public override string GetKullaniciTipi()
        {
            return "Yönetici";
        }
    }
}
