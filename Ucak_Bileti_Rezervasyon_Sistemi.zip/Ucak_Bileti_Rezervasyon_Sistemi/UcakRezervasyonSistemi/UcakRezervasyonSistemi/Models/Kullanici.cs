﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Models
{
    // Abstract sınıf - Ortak kullanıcı özellikleri
    public abstract class Kullanici
    {
        // Properties (Özellikler)
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Email { get; set; }
        public string Sifre { get; set; }
        public string TelefonNo { get; set; }
        public KullaniciRolu Rol { get; set; }

        // Constructor (Yapıcı metot)
        public Kullanici()
        {
        }

        public Kullanici(int id, string ad, string soyad, string email, string sifre, string telefonNo)
        {
            Id = id;
            Ad = ad;
            Soyad = soyad;
            Email = email;
            Sifre = sifre;
            TelefonNo = telefonNo;
        }

        // Abstract metot - Her kullanıcı tipinde farklı olacak
        public abstract string GetKullaniciTipi();

        // Sanal metot - İstenirse override edilebilir
        public virtual string GetTamIsim()
        {
            return $"{Ad} {Soyad}";
        }
    }
}