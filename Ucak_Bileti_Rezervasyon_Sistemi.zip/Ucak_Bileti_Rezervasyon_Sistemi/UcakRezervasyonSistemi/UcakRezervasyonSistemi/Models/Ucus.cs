﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UcakRezervasyonSistemi.Models
{
    // Uçuş sınıfı
    public class Ucus
    {
        // Properties
        public string UcusNo { get; set; }
        public string KalkisYeri { get; set; }
        public string VarisYeri { get; set; }
        public DateTime KalkisTarihi { get; set; }
        public TimeSpan KalkisSaati { get; set; }
        public TimeSpan UcusSuresi { get; set; }
        public decimal TemelFiyat { get; set; }  // Ekonomi sınıfı için temel fiyat
        public Ucak Ucak { get; set; }
        public bool AktifMi { get; set; }

        // Constructor
        public Ucus()
        {
            AktifMi = true;
        }

        public Ucus(string ucusNo, string kalkisYeri, string varisYeri,
                    DateTime kalkisTarihi, TimeSpan kalkisSaati, TimeSpan ucusSuresi,
                    decimal temelFiyat, Ucak ucak)
        {
            UcusNo = ucusNo;
            KalkisYeri = kalkisYeri;
            VarisYeri = varisYeri;
            KalkisTarihi = kalkisTarihi;
            KalkisSaati = kalkisSaati;
            UcusSuresi = ucusSuresi;
            TemelFiyat = temelFiyat;
            Ucak = ucak;
            AktifMi = true;
        }

        // Uçuşa kalan gün sayısını hesapla
        public int GetKalanGun()
        {
            DateTime ucusTarihSaat = KalkisTarihi.Date + KalkisSaati;
            TimeSpan fark = ucusTarihSaat - DateTime.Now;
            return fark.Days;
        }

        // Uçuş doluluk oranını getir
        public double GetDolulukOrani()
        {
            return Ucak?.GetDolulukOrani() ?? 0;
        }

        // Boş koltuk var mı kontrolü
        public bool BosKoltukVarMi()
        {
            return Ucak != null && Ucak.GetBosKoltukSayisi() > 0;
        }

        // Uçuş bilgilerini string olarak döndür
        public override string ToString()
        {
            return $"{UcusNo} - {KalkisYeri} → {VarisYeri} - {KalkisTarihi:dd.MM.yyyy} {KalkisSaati}";
        }

        // Tam uçuş bilgisi
        public string GetDetayliBilgi()
        {
            return $"Uçuş No: {UcusNo}\n" +
                   $"Kalkış: {KalkisYeri}\n" +
                   $"Varış: {VarisYeri}\n" +
                   $"Tarih: {KalkisTarihi:dd.MM.yyyy}\n" +
                   $"Saat: {KalkisSaati}\n" +
                   $"Süre: {UcusSuresi}\n" +
                   $"Temel Fiyat: {TemelFiyat:C}\n" +
                   $"Boş Koltuk: {Ucak?.GetBosKoltukSayisi() ?? 0}";
        }
    }
}