﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace UcakRezervasyonSistemi.Models
{
    // Uçak sınıfı
    public class Ucak
    {
        // Properties
        public string UcakId { get; set; }
        public string Model { get; set; }
        public int ToplamKapasite { get; set; }
        public List<Koltuk> Koltuklar { get; set; }

        // Constructor
        public Ucak()
        {
            Koltuklar = new List<Koltuk>();
        }

        public Ucak(string ucakId, string model, int toplamKapasite)
        {
            UcakId = ucakId;
            Model = model;
            ToplamKapasite = toplamKapasite;
            Koltuklar = new List<Koltuk>();
        }

        // Uçağa koltuk ekle
        public void KoltukEkle(Koltuk koltuk)
        {
            if (Koltuklar.Count < ToplamKapasite)
            {
                Koltuklar.Add(koltuk);
            }
        }

        // Boş koltuk sayısını getir
        public int GetBosKoltukSayisi()
        {
            return Koltuklar.Count(k => k.Durum == Utils.KoltukDurumu.Bos);
        }

        // Dolu koltuk sayısını getir
        public int GetDoluKoltukSayisi()
        {
            return Koltuklar.Count(k => k.Durum == Utils.KoltukDurumu.Dolu);
        }

        // Doluluk oranını hesapla (yüzde)
        public double GetDolulukOrani()
        {
            if (Koltuklar.Count == 0) return 0;
            return (double)GetDoluKoltukSayisi() / Koltuklar.Count * 100;
        }

        // Koltuk numarasına göre koltuk bul
        public Koltuk GetKoltuk(string koltukNo)
        {
            return Koltuklar.FirstOrDefault(k => k.KoltukNo == koltukNo);
        }
    }
}
