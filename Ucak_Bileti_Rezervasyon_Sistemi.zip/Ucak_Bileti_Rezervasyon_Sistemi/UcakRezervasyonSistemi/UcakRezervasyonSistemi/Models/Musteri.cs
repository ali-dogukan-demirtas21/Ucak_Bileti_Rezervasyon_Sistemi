﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Models
{
    // Müşteri sınıfı - Kullanıcı sınıfından türetilmiş (Inheritance)
    public class Musteri : Kullanici
    {
        // Müşteriye özel özellikler
        public string TcNo { get; set; }
        public DateTime KayitTarihi { get; set; }

        // Constructor
        public Musteri()
        {
            Rol = KullaniciRolu.Musteri;
            KayitTarihi = DateTime.Now;
        }

        public Musteri(int id, string ad, string soyad, string email, string sifre,
                       string telefonNo, string tcNo)
            : base(id, ad, soyad, email, sifre, telefonNo)
        {
            TcNo = tcNo;
            Rol = KullaniciRolu.Musteri;
            KayitTarihi = DateTime.Now;
        }

        // Abstract metodun implementasyonu (Polymorphism)
        public override string GetKullaniciTipi()
        {
            return "Müşteri";
        }
    }
}
