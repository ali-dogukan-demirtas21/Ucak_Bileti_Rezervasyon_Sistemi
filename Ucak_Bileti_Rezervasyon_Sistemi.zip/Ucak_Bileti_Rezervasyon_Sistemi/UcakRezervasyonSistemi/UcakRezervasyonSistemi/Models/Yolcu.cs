﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UcakRezervasyonSistemi.Models
{
    // Yolcu sınıfı - Rezervasyonda yer alacak yolcu bilgileri
    public class Yolcu
    {
        // Properties
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string TcNo { get; set; }
        public DateTime DogumTarihi { get; set; }
        public string Cinsiyet { get; set; }
        public string TelefonNo { get; set; }

        // Constructor
        public Yolcu()
        {
        }

        public Yolcu(int id, string ad, string soyad, string tcNo,
                     DateTime dogumTarihi, string cinsiyet, string telefonNo)
        {
            Id = id;
            Ad = ad;
            Soyad = soyad;
            TcNo = tcNo;
            DogumTarihi = dogumTarihi;
            Cinsiyet = cinsiyet;
            TelefonNo = telefonNo;
        }

        // Yaş hesaplama
        public int GetYas()
        {
            int yas = DateTime.Now.Year - DogumTarihi.Year;
            if (DateTime.Now.DayOfYear < DogumTarihi.DayOfYear)
                yas--;
            return yas;
        }

        // Tam isim
        public string GetTamIsim()
        {
            return $"{Ad} {Soyad}";
        }

        // Yolcu bilgilerini string olarak döndür
        public override string ToString()
        {
            return $"{GetTamIsim()} - TC: {TcNo}";
        }
    }
}
