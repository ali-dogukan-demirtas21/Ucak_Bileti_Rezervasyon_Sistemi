﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Models
{
    // Rezervasyon sınıfı
    public class Rezervasyon
    {
        // Properties
        public string RezervasyonNo { get; set; }
        public int MusteriId { get; set; }  // Rezervasyonu yapan müşteri
        public Yolcu Yolcu { get; set; }    // Uçacak yolcu
        public Ucus Ucus { get; set; }
        public Koltuk Koltuk { get; set; }
        public decimal ToplamFiyat { get; set; }
        public DateTime RezervasyonTarihi { get; set; }
        public RezervasyonDurumu Durum { get; set; }

        // Constructor
        public Rezervasyon()
        {
            RezervasyonTarihi = DateTime.Now;
            Durum = RezervasyonDurumu.Aktif;
        }

        public Rezervasyon(string rezervasyonNo, int musteriId, Yolcu yolcu,
                          Ucus ucus, Koltuk koltuk, decimal toplamFiyat)
        {
            RezervasyonNo = rezervasyonNo;
            MusteriId = musteriId;
            Yolcu = yolcu;
            Ucus = ucus;
            Koltuk = koltuk;
            ToplamFiyat = toplamFiyat;
            RezervasyonTarihi = DateTime.Now;
            Durum = RezervasyonDurumu.Aktif;
        }

        // Rezervasyonu iptal et
        public bool RezervasyonuIptalEt()
        {
            if (Durum == RezervasyonDurumu.Aktif)
            {
                Durum = RezervasyonDurumu.IptalEdildi;
                Koltuk?.KoltuguSerbestBirak();  // Koltuğu serbest bırak
                return true;
            }
            return false;
        }

        // Rezervasyon özet bilgisi
        public string GetOzetBilgi()
        {
            return $"Rezervasyon No: {RezervasyonNo}\n" +
                   $"Yolcu: {Yolcu?.GetTamIsim()}\n" +
                   $"Uçuş: {Ucus?.UcusNo} ({Ucus?.KalkisYeri} - {Ucus?.VarisYeri})\n" +
                   $"Koltuk: {Koltuk?.KoltukNo}\n" +
                   $"Tarih: {Ucus?.KalkisTarihi:dd.MM.yyyy} {Ucus?.KalkisSaati}\n" +
                   $"Fiyat: {ToplamFiyat:C}\n" +
                   $"Durum: {Durum}";
        }

        // ToString override
        public override string ToString()
        {
            return $"{RezervasyonNo} - {Yolcu?.GetTamIsim()} - {Ucus?.UcusNo} - {Durum}";
        }
    }
}