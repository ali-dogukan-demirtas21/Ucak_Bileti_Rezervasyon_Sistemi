﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Models
{
    // Koltuk sınıfı
    public class Koltuk
    {
        // Properties
        public string KoltukNo { get; set; }  // Örnek: "1A", "12C"
        public KoltukTipi Tip { get; set; }
        public KoltukDurumu Durum { get; set; }
        public decimal Fiyat { get; set; }

        // Constructor
        public Koltuk()
        {
            Durum = KoltukDurumu.Bos;
        }

        public Koltuk(string koltukNo, KoltukTipi tip, decimal fiyat)
        {
            KoltukNo = koltukNo;
            Tip = tip;
            Fiyat = fiyat;
            Durum = KoltukDurumu.Bos;
        }

        // Koltuğu rezerve et
        public bool KoltuguRezerveEt()
        {
            if (Durum == KoltukDurumu.Bos)
            {
                Durum = KoltukDurumu.Dolu;
                return true;
            }
            return false;
        }

        // Koltuğu serbest bırak
        public void KoltuguSerbestBirak()
        {
            Durum = KoltukDurumu.Bos;
        }

        // Koltuk bilgisini string olarak döndür
        public override string ToString()
        {
            return $"{KoltukNo} - {Tip} - {Durum}";
        }
    }
}
