﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Data;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Services
{
    // Uçuş işlemlerini yöneten servis
    public class UcusServisi
    {
        private VeriYoneticisi veriYoneticisi;
        private List<Ucus> ucuslar;

        // Constructor
        public UcusServisi()
        {
            veriYoneticisi = new VeriYoneticisi();
            ucuslar = veriYoneticisi.UcuslariOku();
        }

        // Uçuş ekle
        public bool UcusEkle(Ucus ucus)
        {
            // Uçuş No kontrolü
            if (ucuslar.Any(u => u.UcusNo == ucus.UcusNo))
            {
                return false; // Bu uçuş numarası zaten var
            }

            ucuslar.Add(ucus);
            veriYoneticisi.UcuslariKaydet(ucuslar);
            return true;
        }

        // Uçuş güncelle
        public bool UcusGuncelle(Ucus guncelUcus)
        {
            var mevcutUcus = ucuslar.FirstOrDefault(u => u.UcusNo == guncelUcus.UcusNo);
            if (mevcutUcus == null)
                return false;

            // Güncelleme
            mevcutUcus.KalkisYeri = guncelUcus.KalkisYeri;
            mevcutUcus.VarisYeri = guncelUcus.VarisYeri;
            mevcutUcus.KalkisTarihi = guncelUcus.KalkisTarihi;
            mevcutUcus.KalkisSaati = guncelUcus.KalkisSaati;
            mevcutUcus.UcusSuresi = guncelUcus.UcusSuresi;
            mevcutUcus.TemelFiyat = guncelUcus.TemelFiyat;
            mevcutUcus.AktifMi = guncelUcus.AktifMi;

            veriYoneticisi.UcuslariKaydet(ucuslar);
            return true;
        }

        // Uçuş sil (pasif yap)
        public bool UcusSil(string ucusNo)
        {
            var ucus = ucuslar.FirstOrDefault(u => u.UcusNo == ucusNo);
            if (ucus == null)
                return false;

            ucus.AktifMi = false;
            veriYoneticisi.UcuslariKaydet(ucuslar);
            return true;
        }

        // Tüm aktif uçuşları getir
        public List<Ucus> GetAktifUcuslar()
        {
            return ucuslar.Where(u => u.AktifMi).ToList();
        }

        // Uçuş ara
        public List<Ucus> UcusAra(string kalkisYeri, string varisYeri, DateTime tarih)
        {
            return ucuslar.Where(u =>
                u.AktifMi &&
                u.KalkisYeri.ToLower().Contains(kalkisYeri.ToLower()) &&
                u.VarisYeri.ToLower().Contains(varisYeri.ToLower()) &&
                u.KalkisTarihi.Date == tarih.Date &&
                u.BosKoltukVarMi()
            ).ToList();
        }

        // Uçuş numarasına göre uçuş getir
        public Ucus GetUcus(string ucusNo)
        {
            return ucuslar.FirstOrDefault(u => u.UcusNo == ucusNo);
        }

        // Örnek uçuşlar oluştur (ilk kurulumda)
        public void OrnekUcuslarOlustur()
        {
            if (ucuslar.Any())
                return; // Zaten uçuş var

            // Örnek uçak 1
            var ucak1 = new Ucak("TC-001", "Boeing 737", 180);
            OrnekKoltuklarOlustur(ucak1, 150, 20, 10); // 150 Ekonomi, 20 Business, 10 First Class

            // Örnek uçak 2
            var ucak2 = new Ucak("TC-002", "Airbus A320", 150);
            OrnekKoltuklarOlustur(ucak2, 120, 20, 10);

            // Örnek uçuşlar
            var ucus1 = new Ucus(
                "TK001",
                "İstanbul",
                "Ankara",
                DateTime.Today.AddDays(3),
                new TimeSpan(10, 30, 0),
                new TimeSpan(1, 15, 0),
                500,
                ucak1
            );

            var ucus2 = new Ucus(
                "TK002",
                "İstanbul",
                "İzmir",
                DateTime.Today.AddDays(5),
                new TimeSpan(14, 45, 0),
                new TimeSpan(1, 0, 0),
                450,
                ucak2
            );

            var ucus3 = new Ucus(
                "TK003",
                "Ankara",
                "Antalya",
                DateTime.Today.AddDays(7),
                new TimeSpan(8, 0, 0),
                new TimeSpan(1, 30, 0),
                600,
                ucak1
            );

            UcusEkle(ucus1);
            UcusEkle(ucus2);
            UcusEkle(ucus3);
        }

        // Uçağa örnek koltuklar ekle
        private void OrnekKoltuklarOlustur(Ucak ucak, int ekonomiSayisi, int businessSayisi, int firstClassSayisi)
        {
            int koltukNo = 1;

            // First Class (1-10)
            for (int i = 0; i < firstClassSayisi; i++)
            {
                char harf = (char)('A' + (i % 4));
                ucak.KoltukEkle(new Koltuk($"{koltukNo}{harf}", KoltukTipi.FirstClass, 2000));
                if ((i + 1) % 4 == 0) koltukNo++;
            }

            // Business Class (11-30)
            koltukNo = 11;
            for (int i = 0; i < businessSayisi; i++)
            {
                char harf = (char)('A' + (i % 4));
                ucak.KoltukEkle(new Koltuk($"{koltukNo}{harf}", KoltukTipi.Business, 1200));
                if ((i + 1) % 4 == 0) koltukNo++;
            }

            // Ekonomi (31+)
            koltukNo = 31;
            for (int i = 0; i < ekonomiSayisi; i++)
            {
                char harf = (char)('A' + (i % 6));
                ucak.KoltukEkle(new Koltuk($"{koltukNo}{harf}", KoltukTipi.Ekonomi, 500));
                if ((i + 1) % 6 == 0) koltukNo++;
            }
        }
    }
}