﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Data;

namespace UcakRezervasyonSistemi.Services
{
    // Kullanıcı giriş ve kimlik doğrulama işlemlerini yöneten servis
    public class KimlikDogrulamaServisi
    {
        private VeriYoneticisi veriYoneticisi;
        private List<Kullanici> kullanicilar;

        // Constructor
        public KimlikDogrulamaServisi()
        {
            veriYoneticisi = new VeriYoneticisi();
            kullanicilar = veriYoneticisi.KullanicilariOku();
        }

        // Kullanıcı girişi
        public Kullanici GirisYap(string email, string sifre)
        {
            var kullanici = kullanicilar.FirstOrDefault(k =>
                k.Email == email && k.Sifre == sifre);

            return kullanici;
        }

        // Yeni müşteri kaydı
        public bool MusteriKaydet(Musteri musteri)
        {
            // Email kontrolü
            if (kullanicilar.Any(k => k.Email == musteri.Email))
            {
                return false; // Bu email zaten kayıtlı
            }

            // TC No kontrolü
            if (kullanicilar.OfType<Musteri>().Any(m => m.TcNo == musteri.TcNo))
            {
                return false; // Bu TC No zaten kayıtlı
            }

            // Yeni ID oluştur
            musteri.Id = kullanicilar.Any() ? kullanicilar.Max(k => k.Id) + 1 : 1;

            // Listeye ekle ve kaydet
            kullanicilar.Add(musteri);
            veriYoneticisi.KullanicilariKaydet(kullanicilar);

            return true;
        }

        // Yeni admin kaydı
        public bool AdminKaydet(Admin admin)
        {
            // Email kontrolü
            if (kullanicilar.Any(k => k.Email == admin.Email))
            {
                return false; // Bu email zaten kayıtlı
            }

            // Yeni ID oluştur
            admin.Id = kullanicilar.Any() ? kullanicilar.Max(k => k.Id) + 1 : 1;

            // Listeye ekle ve kaydet
            kullanicilar.Add(admin);
            veriYoneticisi.KullanicilariKaydet(kullanicilar);

            return true;
        }

        // Email var mı kontrolü
        public bool EmailKayitliMi(string email)
        {
            return kullanicilar.Any(k => k.Email == email);
        }

        // TC No var mı kontrolü
        public bool TcNoKayitliMi(string tcNo)
        {
            return kullanicilar.OfType<Musteri>().Any(m => m.TcNo == tcNo);
        }

        // ID'ye göre kullanıcı getir
        public Kullanici GetKullanici(int id)
        {
            return kullanicilar.FirstOrDefault(k => k.Id == id);
        }

        // Tüm müşterileri getir
        public List<Musteri> GetTumMusteriler()
        {
            return kullanicilar.OfType<Musteri>().ToList();
        }
    }
}