﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Data;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Services
{
    // Rezervasyon işlemlerini yöneten servis
    public class RezervasyonServisi
    {
        private VeriYoneticisi veriYoneticisi;
        private List<Rezervasyon> rezervasyonlar;
        private UcusServisi ucusServisi;
        private FiyatlandirmaServisi fiyatlandirmaServisi;

        // Constructor
        public RezervasyonServisi()
        {
            veriYoneticisi = new VeriYoneticisi();
            rezervasyonlar = veriYoneticisi.RezervasyonlariOku();
            ucusServisi = new UcusServisi();
            fiyatlandirmaServisi = new FiyatlandirmaServisi();
        }

        // Rezervasyon oluştur
        public string RezervasyonOlustur(int musteriId, Yolcu yolcu, string ucusNo,
                                          string koltukNo, string kuponKodu = "")
        {
            try
            {
                // Uçuşu bul
                var ucus = ucusServisi.GetUcus(ucusNo);
                if (ucus == null || !ucus.AktifMi)
                    return null;

                // Koltuğu bul
                var koltuk = ucus.Ucak.GetKoltuk(koltukNo);
                if (koltuk == null || koltuk.Durum != KoltukDurumu.Bos)
                    return null;

                // Koltuğu rezerve et
                if (!koltuk.KoltuguRezerveEt())
                    return null;

                // Fiyat hesapla
                decimal fiyat = fiyatlandirmaServisi.FiyatHesapla(ucus, koltuk.Tip, kuponKodu);

                // Yolcuya ID ata
                if (yolcu.Id == 0)
                {
                    yolcu.Id = GetSonrakiYolcuId();
                }

                // Rezervasyon numarası oluştur
                string rezervasyonNo = GenerateRezervasyonNo();

                // Rezervasyon oluştur
                var rezervasyon = new Rezervasyon(
                    rezervasyonNo,
                    musteriId,
                    yolcu,
                    ucus,
                    koltuk,
                    fiyat
                );

                // Listeye ekle
                rezervasyonlar.Add(rezervasyon);

                // Dosyaya kaydet
                veriYoneticisi.RezervasyonlariKaydet(rezervasyonlar);
                ucusServisi = new UcusServisi(); // Uçuşları yeniden yükle

                return rezervasyonNo;
            }
            catch (Exception)
            {
                return null;
            }
        }

        // Rezervasyon iptal et
        public bool RezervasyonIptalEt(string rezervasyonNo, int musteriId)
        {
            var rezervasyon = rezervasyonlar.FirstOrDefault(r =>
                r.RezervasyonNo == rezervasyonNo &&
                r.MusteriId == musteriId &&
                r.Durum == RezervasyonDurumu.Aktif);

            if (rezervasyon == null)
                return false;

            // Rezervasyonu iptal et
            bool basarili = rezervasyon.RezervasyonuIptalEt();

            if (basarili)
            {
                veriYoneticisi.RezervasyonlariKaydet(rezervasyonlar);
                // Uçuş verilerini de güncelle
                ucusServisi = new UcusServisi();
            }

            return basarili;
        }

        // Müşterinin rezervasyonlarını getir
        public List<Rezervasyon> GetMusteriRezervasyonlari(int musteriId)
        {
            return rezervasyonlar
                .Where(r => r.MusteriId == musteriId)
                .OrderByDescending(r => r.RezervasyonTarihi)
                .ToList();
        }

        // Müşterinin aktif rezervasyonlarını getir
        public List<Rezervasyon> GetMusteriAktifRezervasyonlari(int musteriId)
        {
            return rezervasyonlar
                .Where(r => r.MusteriId == musteriId && r.Durum == RezervasyonDurumu.Aktif)
                .OrderByDescending(r => r.RezervasyonTarihi)
                .ToList();
        }

        // Rezervasyon numarasına göre rezervasyon getir
        public Rezervasyon GetRezervasyon(string rezervasyonNo)
        {
            return rezervasyonlar.FirstOrDefault(r => r.RezervasyonNo == rezervasyonNo);
        }

        // Tüm rezervasyonları getir (Admin için)
        public List<Rezervasyon> GetTumRezervasyonlar()
        {
            return rezervasyonlar.OrderByDescending(r => r.RezervasyonTarihi).ToList();
        }

        // Uçuşa ait rezervasyonları getir
        public List<Rezervasyon> GetUcusRezervasyonlari(string ucusNo)
        {
            return rezervasyonlar
                .Where(r => r.Ucus.UcusNo == ucusNo && r.Durum == RezervasyonDurumu.Aktif)
                .ToList();
        }

        // Rezervasyon numarası oluştur
        private string GenerateRezervasyonNo()
        {
            string tarih = DateTime.Now.ToString("yyyyMMdd");
            int sira = rezervasyonlar.Count(r => r.RezervasyonNo.StartsWith("RZV" + tarih)) + 1;
            return $"RZV{tarih}{sira:D4}";
        }

        // Sonraki yolcu ID'sini getir
        private int GetSonrakiYolcuId()
        {
            if (!rezervasyonlar.Any())
                return 1;

            return rezervasyonlar.Max(r => r.Yolcu.Id) + 1;
        }

        // Rezervasyon istatistikleri
        public Dictionary<string, int> GetRezervasyonIstatistikleri()
        {
            return new Dictionary<string, int>
            {
                { "Toplam", rezervasyonlar.Count },
                { "Aktif", rezervasyonlar.Count(r => r.Durum == RezervasyonDurumu.Aktif) },
                { "İptal", rezervasyonlar.Count(r => r.Durum == RezervasyonDurumu.IptalEdildi) },
                { "Tamamlanan", rezervasyonlar.Count(r => r.Durum == RezervasyonDurumu.Tamamlandi) }
            };
        }

        // Toplam kazanç hesapla
        public decimal GetToplamKazanc()
        {
            return rezervasyonlar
                .Where(r => r.Durum == RezervasyonDurumu.Aktif || r.Durum == RezervasyonDurumu.Tamamlandi)
                .Sum(r => r.ToplamFiyat);
        }
    }
}
