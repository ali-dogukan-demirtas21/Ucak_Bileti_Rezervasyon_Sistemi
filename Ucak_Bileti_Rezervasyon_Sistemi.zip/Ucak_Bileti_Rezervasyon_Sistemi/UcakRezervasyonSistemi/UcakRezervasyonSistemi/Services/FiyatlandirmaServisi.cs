﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi.Services
{
    // Dinamik fiyatlandırma işlemlerini yöneten servis
    public class FiyatlandirmaServisi
    {
        // Dinamik fiyat hesapla
        public decimal FiyatHesapla(Ucus ucus, KoltukTipi koltukTipi, string kuponKodu = "")
        {
            decimal temelFiyat = ucus.TemelFiyat;

            // 1. Koltuk tipine göre çarpan
            decimal koltukCarpani = GetKoltukTipiCarpani(koltukTipi);
            temelFiyat *= koltukCarpani;

            // 2. Doluluk oranına göre artış
            double dolulukOrani = ucus.GetDolulukOrani();
            decimal dolulukCarpani = GetDolulukCarpani(dolulukOrani);
            temelFiyat *= dolulukCarpani;

            // 3. Uçuşa kalan güne göre fiyat
            int kalanGun = ucus.GetKalanGun();
            decimal gunCarpani = GetKalanGunCarpani(kalanGun);
            temelFiyat *= gunCarpani;

            // 4. Sezona göre fiyat (basit mantık)
            decimal sezonCarpani = GetSezonCarpani(ucus.KalkisTarihi);
            temelFiyat *= sezonCarpani;

            // 5. Kupon indirimi
            decimal kuponIndirimi = GetKuponIndirimi(kuponKodu);
            temelFiyat *= (1 - kuponIndirimi);

            // Fiyatı yuvarla
            return Math.Round(temelFiyat, 2);
        }

        // Koltuk tipi çarpanı
        private decimal GetKoltukTipiCarpani(KoltukTipi tip)
        {
            switch (tip)
            {
                case KoltukTipi.Ekonomi:
                    return 1.0m;
                case KoltukTipi.Business:
                    return 2.5m;
                case KoltukTipi.FirstClass:
                    return 4.0m;
                default:
                    return 1.0m;
            }
        }

        // Doluluk oranına göre çarpan
        private decimal GetDolulukCarpani(double dolulukOrani)
        {
            if (dolulukOrani >= 90)
                return 1.5m;  // %90+ dolu ise %50 artış
            else if (dolulukOrani >= 70)
                return 1.3m;  // %70-90 dolu ise %30 artış
            else if (dolulukOrani >= 50)
                return 1.15m; // %50-70 dolu ise %15 artış
            else
                return 1.0m;  // %50'den az ise normal fiyat
        }

        // Kalan güne göre çarpan
        private decimal GetKalanGunCarpani(int kalanGun)
        {
            if (kalanGun <= 3)
                return 1.4m;  // 3 gün ve altı %40 artış
            else if (kalanGun <= 7)
                return 1.2m;  // 7 gün ve altı %20 artış
            else if (kalanGun <= 14)
                return 1.1m;  // 14 gün ve altı %10 artış
            else if (kalanGun <= 30)
                return 1.0m;  // Normal fiyat
            else
                return 0.85m; // Erken rezervasyon %15 indirim
        }

        // Sezon çarpanı (basit)
        private decimal GetSezonCarpani(DateTime tarih)
        {
            int ay = tarih.Month;

            // Yaz sezonu (Haziran-Ağustos)
            if (ay >= 6 && ay <= 8)
                return 1.3m;

            // Kış tatili (Aralık-Ocak)
            if (ay == 12 || ay == 1)
                return 1.2m;

            // Bahar/Sonbahar
            return 1.0m;
        }

        // Kupon indirimi
        private decimal GetKuponIndirimi(string kuponKodu)
        {
            if (string.IsNullOrWhiteSpace(kuponKodu))
                return 0m;

            // Örnek kupon kodları
            switch (kuponKodu.ToUpper())
            {
                case "YENI10":
                    return 0.10m; // %10 indirim
                case "KAMPANYA20":
                    return 0.20m; // %20 indirim
                case "ERKEN15":
                    return 0.15m; // %15 indirim
                default:
                    return 0m;
            }
        }

        // Fiyat detaylarını string olarak döndür
        public string GetFiyatDetaylari(Ucus ucus, KoltukTipi koltukTipi)
        {
            decimal temelFiyat = ucus.TemelFiyat;
            decimal koltukCarpani = GetKoltukTipiCarpani(koltukTipi);
            decimal dolulukCarpani = GetDolulukCarpani(ucus.GetDolulukOrani());
            decimal gunCarpani = GetKalanGunCarpani(ucus.GetKalanGun());
            decimal sezonCarpani = GetSezonCarpani(ucus.KalkisTarihi);

            return $"Temel Fiyat: {temelFiyat:C}\n" +
                   $"Koltuk Tipi Çarpanı: x{koltukCarpani}\n" +
                   $"Doluluk Çarpanı: x{dolulukCarpani}\n" +
                   $"Tarih Çarpanı: x{gunCarpani}\n" +
                   $"Sezon Çarpanı: x{sezonCarpani}\n" +
                   $"─────────────────────\n" +
                   $"Toplam: {FiyatHesapla(ucus, koltukTipi):C}";
        }
    }
}