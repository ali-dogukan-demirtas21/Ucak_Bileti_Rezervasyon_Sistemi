﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using UcakRezervasyonSistemi.Models;

namespace UcakRezervasyonSistemi.Data
{
    // Verileri dosyaya kaydetme ve okuma işlemlerini yöneten sınıf
    public class VeriYoneticisi
    {
        // Dosya yolları
        private readonly string dataKlasoruYolu;
        private readonly string kullanicilarDosyaYolu;
        private readonly string ucuslarDosyaYolu;
        private readonly string rezervasyonlarDosyaYolu;

        // Constructor
        public VeriYoneticisi()
        {
            // Uygulama klasöründe Data klasörü oluştur
            dataKlasoruYolu = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data");

            // Dosya yollarını belirle
            kullanicilarDosyaYolu = Path.Combine(dataKlasoruYolu, "kullanicilar.json");
            ucuslarDosyaYolu = Path.Combine(dataKlasoruYolu, "ucuslar.json");
            rezervasyonlarDosyaYolu = Path.Combine(dataKlasoruYolu, "rezervasyonlar.json");

            // Data klasörünü oluştur (yoksa)
            if (!Directory.Exists(dataKlasoruYolu))
            {
                Directory.CreateDirectory(dataKlasoruYolu);
            }
        }

        // --- KULLANICI İŞLEMLERİ ---

        // Kullanıcıları kaydet
        public void KullanicilariKaydet(List<Kullanici> kullanicilar)
        {
            try
            {
                string json = JsonConvert.SerializeObject(kullanicilar, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        TypeNameHandling = TypeNameHandling.Auto
                    });
                File.WriteAllText(kullanicilarDosyaYolu, json);
            }
            catch (Exception ex)
            {
                throw new Exception($"Kullanıcılar kaydedilirken hata: {ex.Message}");
            }
        }

        // Kullanıcıları oku
        public List<Kullanici> KullanicilariOku()
        {
            try
            {
                if (!File.Exists(kullanicilarDosyaYolu))
                    return new List<Kullanici>();

                string json = File.ReadAllText(kullanicilarDosyaYolu);
                return JsonConvert.DeserializeObject<List<Kullanici>>(json,
                    new JsonSerializerSettings
                    {
                        TypeNameHandling = TypeNameHandling.Auto
                    }) ?? new List<Kullanici>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Kullanıcılar okunurken hata: {ex.Message}");
            }
        }

        // --- UÇUŞ İŞLEMLERİ ---

        // Uçuşları kaydet
        public void UcuslariKaydet(List<Ucus> ucuslar)
        {
            try
            {
                string json = JsonConvert.SerializeObject(ucuslar, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    });
                File.WriteAllText(ucuslarDosyaYolu, json);
            }
            catch (Exception ex)
            {
                throw new Exception($"Uçuşlar kaydedilirken hata: {ex.Message}");
            }
        }

        // Uçuşları oku
        public List<Ucus> UcuslariOku()
        {
            try
            {
                if (!File.Exists(ucuslarDosyaYolu))
                    return new List<Ucus>();

                string json = File.ReadAllText(ucuslarDosyaYolu);
                return JsonConvert.DeserializeObject<List<Ucus>>(json) ?? new List<Ucus>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Uçuşlar okunurken hata: {ex.Message}");
            }
        }

        // --- REZERVASYON İŞLEMLERİ ---

        // Rezervasyonları kaydet
        public void RezervasyonlariKaydet(List<Rezervasyon> rezervasyonlar)
        {
            try
            {
                string json = JsonConvert.SerializeObject(rezervasyonlar, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    });
                File.WriteAllText(rezervasyonlarDosyaYolu, json);
            }
            catch (Exception ex)
            {
                throw new Exception($"Rezervasyonlar kaydedilirken hata: {ex.Message}");
            }
        }

        // Rezervasyonları oku
        public List<Rezervasyon> RezervasyonlariOku()
        {
            try
            {
                if (!File.Exists(rezervasyonlarDosyaYolu))
                    return new List<Rezervasyon>();

                string json = File.ReadAllText(rezervasyonlarDosyaYolu);
                return JsonConvert.DeserializeObject<List<Rezervasyon>>(json) ?? new List<Rezervasyon>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Rezervasyonlar okunurken hata: {ex.Message}");
            }
        }

        // Tüm verileri sil (test için)
        public void TumVerileriSil()
        {
            if (File.Exists(kullanicilarDosyaYolu))
                File.Delete(kullanicilarDosyaYolu);
            if (File.Exists(ucuslarDosyaYolu))
                File.Delete(ucuslarDosyaYolu);
            if (File.Exists(rezervasyonlarDosyaYolu))
                File.Delete(rezervasyonlarDosyaYolu);
        }
    }
}