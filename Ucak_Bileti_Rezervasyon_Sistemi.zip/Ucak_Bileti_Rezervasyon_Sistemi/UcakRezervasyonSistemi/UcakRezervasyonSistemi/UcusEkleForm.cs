﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi
{
    public partial class UcusEkleForm : Form
    {
        private UcusServisi ucusServisi;

        // Kontroller
        private Label lblBaslik;
        private Label lblUcusNo;
        private TextBox txtUcusNo;
        private Label lblKalkis;
        private TextBox txtKalkis;
        private Label lblVaris;
        private TextBox txtVaris;
        private Label lblTarih;
        private DateTimePicker dtpTarih;
        private Label lblSaat;
        private NumericUpDown numSaat;
        private NumericUpDown numDakika;
        private Label lblUcusSuresi;
        private NumericUpDown numSureSaat;
        private NumericUpDown numSureDakika;
        private Label lblFiyat;
        private NumericUpDown numFiyat;
        private Label lblUcakModel;
        private TextBox txtUcakModel;
        private Label lblKapasite;
        private NumericUpDown numKapasite;
        private Button btnKaydet;
        private Button btnIptal;

        public UcusEkleForm()
        {
            InitializeComponent();
            ucusServisi = new UcusServisi();

            // Form ayarları
            this.Text = "Yeni Uçuş Ekle";
            this.Size = new Size(500, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            KontrolleriOlustur();
        }

        private void KontrolleriOlustur()
        {
            int x = 50;
            int y = 30;
            int labelGenislik = 120;
            int kontrolGenislik = 280;

            // Başlık
            lblBaslik = new Label
            {
                Text = "YENİ UÇUŞ EKLE",
                Font = new Font("Arial", 16, FontStyle.Bold),
                Location = new Point(140, y),
                AutoSize = true
            };
            this.Controls.Add(lblBaslik);
            y += 50;

            // Uçuş No
            lblUcusNo = new Label
            {
                Text = "Uçuş No:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblUcusNo);

            txtUcusNo = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtUcusNo);
            y += 40;

            // Kalkış Yeri
            lblKalkis = new Label
            {
                Text = "Kalkış Yeri:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblKalkis);

            txtKalkis = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtKalkis);
            y += 40;

            // Varış Yeri
            lblVaris = new Label
            {
                Text = "Varış Yeri:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblVaris);

            txtVaris = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtVaris);
            y += 40;

            // Kalkış Tarihi
            lblTarih = new Label
            {
                Text = "Kalkış Tarihi:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblTarih);

            dtpTarih = new DateTimePicker
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Format = DateTimePickerFormat.Short,
                MinDate = DateTime.Today
            };
            this.Controls.Add(dtpTarih);
            y += 40;

            // Kalkış Saati
            lblSaat = new Label
            {
                Text = "Kalkış Saati:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblSaat);

            numSaat = new NumericUpDown
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(80, 25),
                Minimum = 0,
                Maximum = 23,
                Value = 10
            };
            this.Controls.Add(numSaat);

            Label lblSaatAyrac = new Label
            {
                Text = ":",
                Location = new Point(x + labelGenislik + 85, y),
                Size = new Size(10, 20),
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            this.Controls.Add(lblSaatAyrac);

            numDakika = new NumericUpDown
            {
                Location = new Point(x + labelGenislik + 100, y),
                Size = new Size(80, 25),
                Minimum = 0,
                Maximum = 59,
                Value = 0
            };
            this.Controls.Add(numDakika);
            y += 40;

            // Uçuş Süresi
            lblUcusSuresi = new Label
            {
                Text = "Uçuş Süresi:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblUcusSuresi);

            numSureSaat = new NumericUpDown
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(80, 25),
                Minimum = 0,
                Maximum = 24,
                Value = 1
            };
            this.Controls.Add(numSureSaat);

            Label lblSureAyrac = new Label
            {
                Text = "saat",
                Location = new Point(x + labelGenislik + 85, y + 3),
                Size = new Size(40, 20)
            };
            this.Controls.Add(lblSureAyrac);

            numSureDakika = new NumericUpDown
            {
                Location = new Point(x + labelGenislik + 125, y),
                Size = new Size(80, 25),
                Minimum = 0,
                Maximum = 59,
                Value = 30
            };
            this.Controls.Add(numSureDakika);

            Label lblSureDakika = new Label
            {
                Text = "dk",
                Location = new Point(x + labelGenislik + 210, y + 3),
                Size = new Size(30, 20)
            };
            this.Controls.Add(lblSureDakika);
            y += 40;

            // Temel Fiyat
            lblFiyat = new Label
            {
                Text = "Temel Fiyat (₺):",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblFiyat);

            numFiyat = new NumericUpDown
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Minimum = 100,
                Maximum = 10000,
                Value = 500,
                Increment = 50
            };
            this.Controls.Add(numFiyat);
            y += 40;

            // Uçak Model
            lblUcakModel = new Label
            {
                Text = "Uçak Modeli:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblUcakModel);

            txtUcakModel = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10),
                Text = "Boeing 737"
            };
            this.Controls.Add(txtUcakModel);
            y += 40;

            // Kapasite
            lblKapasite = new Label
            {
                Text = "Toplam Kapasite:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblKapasite);

            numKapasite = new NumericUpDown
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Minimum = 50,
                Maximum = 500,
                Value = 180,
                Increment = 10
            };
            this.Controls.Add(numKapasite);
            y += 60;

            // Kaydet Butonu
            btnKaydet = new Button
            {
                Text = "Uçuşu Kaydet",
                Location = new Point(x + 50, y),
                Size = new Size(150, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnKaydet.Click += BtnKaydet_Click;
            this.Controls.Add(btnKaydet);

            // İptal Butonu
            btnIptal = new Button
            {
                Text = "İptal",
                Location = new Point(x + 220, y),
                Size = new Size(150, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnIptal.Click += BtnIptal_Click;
            this.Controls.Add(btnIptal);
        }

        // Kaydet butonu
        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            // Validasyon
            if (string.IsNullOrWhiteSpace(txtUcusNo.Text))
            {
                MessageBox.Show("Lütfen uçuş numarası giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUcusNo.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtKalkis.Text))
            {
                MessageBox.Show("Lütfen kalkış yerini giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtKalkis.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtVaris.Text))
            {
                MessageBox.Show("Lütfen varış yerini giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtVaris.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtUcakModel.Text))
            {
                MessageBox.Show("Lütfen uçak modelini giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUcakModel.Focus();
                return;
            }

            try
            {
                // Uçak oluştur
                string ucakId = "TC-" + DateTime.Now.ToString("HHmmss");
                var ucak = new Ucak(ucakId, txtUcakModel.Text, (int)numKapasite.Value);

                // Koltukları oluştur (basit dağılım)
                int ekonomi = (int)((double)numKapasite.Value * 0.7); // %70 ekonomi
                int business = (int)((double)numKapasite.Value * 0.2); // %20 business
                int firstClass = (int)numKapasite.Value - ekonomi - business; // Kalan first class

                OrnekKoltuklarOlustur(ucak, ekonomi, business, firstClass);

                // Uçuş oluştur
                var ucus = new Ucus(
                    txtUcusNo.Text.Trim().ToUpper(),
                    txtKalkis.Text.Trim(),
                    txtVaris.Text.Trim(),
                    dtpTarih.Value.Date,
                    new TimeSpan((int)numSaat.Value, (int)numDakika.Value, 0),
                    new TimeSpan((int)numSureSaat.Value, (int)numSureDakika.Value, 0),
                    numFiyat.Value,
                    ucak
                );

                // Uçuşu kaydet
                bool basarili = ucusServisi.UcusEkle(ucus);

                if (basarili)
                {
                    MessageBox.Show("Uçuş başarıyla eklendi!", "Başarılı",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Bu uçuş numarası zaten kullanılıyor!", "Hata",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUcusNo.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Uçuş eklenirken hata oluştu: {ex.Message}", "Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Koltuları oluştur
        private void OrnekKoltuklarOlustur(Ucak ucak, int ekonomiSayisi, int businessSayisi, int firstClassSayisi)
        {
            int koltukNo = 1;

            // First Class
            for (int i = 0; i < firstClassSayisi; i++)
            {
                char harf = (char)('A' + (i % 4));
                ucak.KoltukEkle(new Koltuk($"{koltukNo}{harf}", KoltukTipi.FirstClass, 2000));
                if ((i + 1) % 4 == 0) koltukNo++;
            }

            // Business Class
            koltukNo = 11;
            for (int i = 0; i < businessSayisi; i++)
            {
                char harf = (char)('A' + (i % 4));
                ucak.KoltukEkle(new Koltuk($"{koltukNo}{harf}", KoltukTipi.Business, 1200));
                if ((i + 1) % 4 == 0) koltukNo++;
            }

            // Ekonomi
            koltukNo = 31;
            for (int i = 0; i < ekonomiSayisi; i++)
            {
                char harf = (char)('A' + (i % 6));
                ucak.KoltukEkle(new Koltuk($"{koltukNo}{harf}", KoltukTipi.Ekonomi, 500));
                if ((i + 1) % 6 == 0) koltukNo++;
            }
        }

        // İptal butonu
        private void BtnIptal_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}