﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;

namespace UcakRezervasyonSistemi
{
    public partial class LoginForm : Form
    {
        private KimlikDogrulamaServisi kimlikServisi;

        // Kontroller
        private Label lblBaslik;
        private Label lblEmail;
        private TextBox txtEmail;
        private Label lblSifre;
        private TextBox txtSifre;
        private Button btnGiris;
        private Button btnKayitOl;

        public LoginForm()
        {
            InitializeComponent();
            kimlikServisi = new KimlikDogrulamaServisi();

            // Form ayarları
            this.Text = "Uçak Rezervasyon Sistemi - Giriş";
            this.Size = new Size(400, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Kontrolleri oluştur
            KontrolleriOlustur();
        }

        private void KontrolleriOlustur()
        {
            // Başlık Label
            lblBaslik = new Label
            {
                Text = "GİRİŞ YAP",
                Font = new Font("Arial", 16, FontStyle.Bold),
                Location = new Point(130, 30),
                AutoSize = true
            };
            this.Controls.Add(lblBaslik);

            // Email Label
            lblEmail = new Label
            {
                Text = "Email:",
                Location = new Point(50, 100),
                AutoSize = true
            };
            this.Controls.Add(lblEmail);

            // Email TextBox
            txtEmail = new TextBox
            {
                Name = "txtEmail",
                Location = new Point(50, 125),
                Size = new Size(280, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtEmail);

            // Şifre Label
            lblSifre = new Label
            {
                Text = "Şifre:",
                Location = new Point(50, 170),
                AutoSize = true
            };
            this.Controls.Add(lblSifre);

            // Şifre TextBox
            txtSifre = new TextBox
            {
                Name = "txtSifre",
                Location = new Point(50, 195),
                Size = new Size(280, 25),
                Font = new Font("Arial", 10),
                PasswordChar = '*'
            };
            this.Controls.Add(txtSifre);

            // Giriş Button
            btnGiris = new Button
            {
                Name = "btnGiris",
                Text = "Giriş Yap",
                Location = new Point(50, 250),
                Size = new Size(130, 40),
                BackColor = Color.LightSkyBlue,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnGiris.Click += BtnGiris_Click;
            this.Controls.Add(btnGiris);

            // Kayıt Ol Button
            btnKayitOl = new Button
            {
                Name = "btnKayitOl",
                Text = "Kayıt Ol",
                Location = new Point(200, 250),
                Size = new Size(130, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnKayitOl.Click += BtnKayitOl_Click;
            this.Controls.Add(btnKayitOl);

            // Enter tuşu ile giriş yapabilme
            txtSifre.KeyPress += (s, e) =>
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    BtnGiris_Click(s, e);
                }
            };
        }

        // Giriş Yap butonu
        private void BtnGiris_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string sifre = txtSifre.Text;

            // Validasyon
            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Lütfen email adresinizi giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(sifre))
            {
                MessageBox.Show("Lütfen şifrenizi giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSifre.Focus();
                return;
            }

            // Giriş kontrolü
            var kullanici = kimlikServisi.GirisYap(email, sifre);

            if (kullanici == null)
            {
                MessageBox.Show("Email veya şifre hatalı!", "Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSifre.Clear();
                txtSifre.Focus();
                return;
            }

            // Giriş başarılı
            MessageBox.Show($"Hoş geldiniz, {kullanici.GetTamIsim()}!", "Başarılı",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Kullanıcı tipine göre yönlendir
            if (kullanici.Rol == Utils.KullaniciRolu.Admin)
            {
                // Admin paneline git
                this.Hide();
                AdminPanel adminPanel = new AdminPanel((Admin)kullanici);
                adminPanel.Show();
            }
            else
            {
                // Müşteri paneline git
                this.Hide();
                MusteriPanel musteriPanel = new MusteriPanel((Musteri)kullanici);
                musteriPanel.Show();
            }
        }

        // Kayıt Ol butonu
        private void BtnKayitOl_Click(object sender, EventArgs e)
        {
            KayitForm kayitForm = new KayitForm();
            if (kayitForm.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Kayıt tamamlandı! Şimdi giriş yapabilirsiniz.", "Bilgi",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}