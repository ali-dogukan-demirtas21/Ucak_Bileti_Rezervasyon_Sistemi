﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;

namespace UcakRezervasyonSistemi
{
    public partial class AdminPanel : Form
    {
        private Admin admin;
        private UcusServisi ucusServisi;
        private RezervasyonServisi rezervasyonServisi;

        // Kontroller
        private Label lblBaslik;
        private Label lblHosgeldin;
        private Button btnUcusEkle;
        private Button btnUcusListele;
        private Button btnRezervasyonlar;
        private Button btnCikis;
        private ListBox lstUcuslar;
        private Label lblBilgi;

        public AdminPanel(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
            ucusServisi = new UcusServisi();
            rezervasyonServisi = new RezervasyonServisi();

            // Form ayarları
            this.Text = "Admin Paneli";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            KontrolleriOlustur();
            UcuslariYukle();
        }

        private void KontrolleriOlustur()
        {
            // Başlık
            lblBaslik = new Label
            {
                Text = "YÖNETİCİ PANELİ",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(280, 20),
                AutoSize = true
            };
            this.Controls.Add(lblBaslik);

            // Hoşgeldin mesajı
            lblHosgeldin = new Label
            {
                Text = $"Hoş geldiniz, {admin.GetTamIsim()}",
                Font = new Font("Arial", 11, FontStyle.Regular),
                Location = new Point(30, 70),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            this.Controls.Add(lblHosgeldin);

            // Uçuş Ekle Butonu
            btnUcusEkle = new Button
            {
                Text = "Yeni Uçuş Ekle",
                Location = new Point(30, 110),
                Size = new Size(150, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnUcusEkle.Click += BtnUcusEkle_Click;
            this.Controls.Add(btnUcusEkle);

            // Uçuş Listele Butonu
            btnUcusListele = new Button
            {
                Text = "Uçuşları Yenile",
                Location = new Point(200, 110),
                Size = new Size(150, 40),
                BackColor = Color.LightBlue,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnUcusListele.Click += BtnUcusListele_Click;
            this.Controls.Add(btnUcusListele);

            // Rezervasyonlar Butonu
            btnRezervasyonlar = new Button
            {
                Text = "Rezervasyonlar",
                Location = new Point(370, 110),
                Size = new Size(150, 40),
                BackColor = Color.LightYellow,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnRezervasyonlar.Click += BtnRezervasyonlar_Click;
            this.Controls.Add(btnRezervasyonlar);

            // Çıkış Butonu
            btnCikis = new Button
            {
                Text = "Çıkış",
                Location = new Point(540, 110),
                Size = new Size(150, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnCikis.Click += BtnCikis_Click;
            this.Controls.Add(btnCikis);

            // Bilgi Label
            lblBilgi = new Label
            {
                Text = "Aktif Uçuşlar:",
                Font = new Font("Arial", 11, FontStyle.Bold),
                Location = new Point(30, 170),
                AutoSize = true
            };
            this.Controls.Add(lblBilgi);

            // Uçuş Listesi
            lstUcuslar = new ListBox
            {
                Location = new Point(30, 200),
                Size = new Size(730, 330),
                Font = new Font("Courier New", 9)
            };
            lstUcuslar.DoubleClick += LstUcuslar_DoubleClick;
            this.Controls.Add(lstUcuslar);
        }

        // Uçuşları yükle
        private void UcuslariYukle()
        {
            lstUcuslar.Items.Clear();
            var ucuslar = ucusServisi.GetAktifUcuslar();

            if (ucuslar.Count == 0)
            {
                lstUcuslar.Items.Add("Henüz uçuş bulunmamaktadır.");
                return;
            }

            // Başlık
            lstUcuslar.Items.Add("─────────────────────────────────────────────────────────────────────────────");
            lstUcuslar.Items.Add(string.Format("{0,-10} {1,-15} {2,-15} {3,-12} {4,-8} {5,-10} {6,-10}",
                "Uçuş No", "Kalkış", "Varış", "Tarih", "Saat", "Fiyat", "Boş Koltuk"));
            lstUcuslar.Items.Add("─────────────────────────────────────────────────────────────────────────────");

            foreach (var ucus in ucuslar)
            {
                string satir = string.Format("{0,-10} {1,-15} {2,-15} {3,-12} {4,-8} {5,-10} {6,-10}",
                    ucus.UcusNo,
                    ucus.KalkisYeri.Length > 14 ? ucus.KalkisYeri.Substring(0, 14) : ucus.KalkisYeri,
                    ucus.VarisYeri.Length > 14 ? ucus.VarisYeri.Substring(0, 14) : ucus.VarisYeri,
                    ucus.KalkisTarihi.ToString("dd.MM.yyyy"),
                    ucus.KalkisSaati.ToString(@"hh\:mm"),
                    ucus.TemelFiyat.ToString("C0"),
                    ucus.Ucak.GetBosKoltukSayisi() + "/" + ucus.Ucak.ToplamKapasite
                );
                lstUcuslar.Items.Add(satir);
            }

            lstUcuslar.Items.Add("─────────────────────────────────────────────────────────────────────────────");
            lstUcuslar.Items.Add($"Toplam {ucuslar.Count} aktif uçuş bulunmaktadır.");
        }

        // Uçuş Ekle butonu
        private void BtnUcusEkle_Click(object sender, EventArgs e)
        {
            UcusEkleForm ucusEkleForm = new UcusEkleForm();
            if (ucusEkleForm.ShowDialog() == DialogResult.OK)
            {
                // Uçuş başarıyla eklendi, listeyi yenile
                ucusServisi = new UcusServisi();
                UcuslariYukle();
            }
        }

        // Uçuşları Yenile butonu
        private void BtnUcusListele_Click(object sender, EventArgs e)
        {
            ucusServisi = new UcusServisi(); // Verileri yeniden yükle
            UcuslariYukle();
            MessageBox.Show("Uçuş listesi güncellendi!", "Bilgi",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Rezervasyonlar butonu
        private void BtnRezervasyonlar_Click(object sender, EventArgs e)
        {
            var rezervasyonlar = rezervasyonServisi.GetTumRezervasyonlar();
            var istatistikler = rezervasyonServisi.GetRezervasyonIstatistikleri();

            string mesaj = $"Toplam Rezervasyon: {istatistikler["Toplam"]}\n" +
                          $"Aktif: {istatistikler["Aktif"]}\n" +
                          $"İptal Edilmiş: {istatistikler["İptal"]}\n" +
                          $"Tamamlanmış: {istatistikler["Tamamlanan"]}\n\n" +
                          $"Toplam Kazanç: {rezervasyonServisi.GetToplamKazanc():C}";

            MessageBox.Show(mesaj, "Rezervasyon İstatistikleri",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Çıkış butonu
        private void BtnCikis_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Çıkış yapmak istediğinize emin misiniz?", "Çıkış",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
                // Login formunu tekrar göster
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }
        }

        // ListBox'a çift tıklanınca detay göster
        private void LstUcuslar_DoubleClick(object sender, EventArgs e)
        {
            if (lstUcuslar.SelectedItem == null) return;

            string seciliSatir = lstUcuslar.SelectedItem.ToString();
            if (seciliSatir.Contains("─") || seciliSatir.Contains("Uçuş No") ||
                seciliSatir.Contains("Toplam") || seciliSatir.Contains("Henüz"))
                return;

            // Uçuş no'yu al (ilk 10 karakter)
            string ucusNo = seciliSatir.Substring(0, 10).Trim();
            var ucus = ucusServisi.GetUcus(ucusNo);

            if (ucus != null)
            {
                MessageBox.Show(ucus.GetDetayliBilgi(), "Uçuş Detayları",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Form kapanınca uygulamayı kapat
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit();
            }
        }

        private void AdminPanel_Load(object sender, EventArgs e)
        {

        }
    }
}