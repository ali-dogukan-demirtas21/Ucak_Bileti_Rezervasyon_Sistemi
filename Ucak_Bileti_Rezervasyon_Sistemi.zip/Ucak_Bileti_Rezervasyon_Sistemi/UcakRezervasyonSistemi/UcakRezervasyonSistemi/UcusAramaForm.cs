﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;

namespace UcakRezervasyonSistemi
{
    public partial class UcusAramaForm : Form
    {
        private Musteri musteri;
        private UcusServisi ucusServisi;
        private List<Ucus> bulunanUcuslar;

        // Kontroller
        private Label lblBaslik;
        private Label lblKalkis;
        private ComboBox cmbKalkis;
        private Label lblVaris;
        private ComboBox cmbVaris;
        private Label lblTarih;
        private DateTimePicker dtpTarih;
        private Button btnAra;
        private Button btnGeri;
        private ListBox lstUcuslar;
        private Button btnDevam;
        private Label lblSonuc;

        public UcusAramaForm(Musteri musteri)
        {
            InitializeComponent();
            this.musteri = musteri;
            ucusServisi = new UcusServisi();
            bulunanUcuslar = new List<Ucus>();

            // Form ayarları
            this.Text = "Uçuş Ara";
            this.Size = new Size(900, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.WhiteSmoke;

            KontrolleriOlustur();
            SehirleriYukle();
        }

        private void KontrolleriOlustur()
        {
            // Başlık
            lblBaslik = new Label
            {
                Text = "UÇUŞ ARAMA",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(350, 20),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            this.Controls.Add(lblBaslik);

            // Kalkış Yeri
            lblKalkis = new Label
            {
                Text = "Kalkış Yeri:",
                Location = new Point(50, 80),
                Size = new Size(100, 20),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(lblKalkis);

            cmbKalkis = new ComboBox
            {
                Location = new Point(160, 78),
                Size = new Size(200, 25),
                Font = new Font("Arial", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            this.Controls.Add(cmbKalkis);

            // Varış Yeri
            lblVaris = new Label
            {
                Text = "Varış Yeri:",
                Location = new Point(390, 80),
                Size = new Size(100, 20),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(lblVaris);

            cmbVaris = new ComboBox
            {
                Location = new Point(500, 78),
                Size = new Size(200, 25),
                Font = new Font("Arial", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            this.Controls.Add(cmbVaris);

            // Tarih
            lblTarih = new Label
            {
                Text = "Kalkış Tarihi:",
                Location = new Point(50, 130),
                Size = new Size(100, 20),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(lblTarih);

            dtpTarih = new DateTimePicker
            {
                Location = new Point(160, 128),
                Size = new Size(200, 25),
                Format = DateTimePickerFormat.Short,
                MinDate = DateTime.Today
            };
            this.Controls.Add(dtpTarih);

            // Ara Butonu
            btnAra = new Button
            {
                Text = "🔍 Ara",
                Location = new Point(390, 125),
                Size = new Size(120, 35),
                BackColor = Color.LightSkyBlue,
                Font = new Font("Arial", 11, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnAra.Click += BtnAra_Click;
            this.Controls.Add(btnAra);

            // Geri Butonu
            btnGeri = new Button
            {
                Text = "← Geri",
                Location = new Point(750, 125),
                Size = new Size(100, 35),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnGeri.Click += BtnGeri_Click;
            this.Controls.Add(btnGeri);

            // Sonuç Label
            lblSonuc = new Label
            {
                Text = "Lütfen arama yapınız...",
                Location = new Point(50, 180),
                Size = new Size(800, 20),
                Font = new Font("Arial", 10, FontStyle.Italic),
                ForeColor = Color.Gray
            };
            this.Controls.Add(lblSonuc);

            // Uçuş Listesi
            lstUcuslar = new ListBox
            {
                Location = new Point(50, 210),
                Size = new Size(800, 340),
                Font = new Font("Courier New", 9),
                SelectionMode = SelectionMode.One
            };
            lstUcuslar.DoubleClick += LstUcuslar_DoubleClick;
            this.Controls.Add(lstUcuslar);

            // Devam Butonu
            btnDevam = new Button
            {
                Text = "Seçili Uçuşla Devam Et →",
                Location = new Point(650, 565),
                Size = new Size(200, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Enabled = false
            };
            btnDevam.Click += BtnDevam_Click;
            this.Controls.Add(btnDevam);
        }

        // Şehirleri yükle
        private void SehirleriYukle()
        {
            var tumUcuslar = ucusServisi.GetAktifUcuslar();
            var sehirler = new HashSet<string>();

            foreach (var ucus in tumUcuslar)
            {
                sehirler.Add(ucus.KalkisYeri);
                sehirler.Add(ucus.VarisYeri);
            }

            cmbKalkis.Items.Clear();
            cmbVaris.Items.Clear();

            foreach (var sehir in sehirler.OrderBy(s => s))
            {
                cmbKalkis.Items.Add(sehir);
                cmbVaris.Items.Add(sehir);
            }

            if (cmbKalkis.Items.Count > 0)
            {
                cmbKalkis.SelectedIndex = 0;
                cmbVaris.SelectedIndex = cmbVaris.Items.Count > 1 ? 1 : 0;
            }
        }

        // Ara butonu
        private void BtnAra_Click(object sender, EventArgs e)
        {
            if (cmbKalkis.SelectedItem == null || cmbVaris.SelectedItem == null)
            {
                MessageBox.Show("Lütfen kalkış ve varış yerini seçiniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string kalkis = cmbKalkis.SelectedItem.ToString();
            string varis = cmbVaris.SelectedItem.ToString();

            if (kalkis == varis)
            {
                MessageBox.Show("Kalkış ve varış yeri aynı olamaz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Uçuş ara
            bulunanUcuslar = ucusServisi.UcusAra(kalkis, varis, dtpTarih.Value);

            lstUcuslar.Items.Clear();
            btnDevam.Enabled = false;

            if (bulunanUcuslar.Count == 0)
            {
                lblSonuc.Text = "Seçtiğiniz kriterlere uygun uçuş bulunamadı.";
                lblSonuc.ForeColor = Color.Red;
                lstUcuslar.Items.Add("Üzgünüz, aradığınız kriterlere uygun uçuş bulunamamıştır.");
                lstUcuslar.Items.Add("");
                lstUcuslar.Items.Add("Lütfen farklı bir tarih veya güzergah deneyin.");
                return;
            }

            lblSonuc.Text = $"{bulunanUcuslar.Count} adet uçuş bulundu. Listeden seçim yapabilirsiniz.";
            lblSonuc.ForeColor = Color.Green;

            // Başlık
            lstUcuslar.Items.Add("═══════════════════════════════════════════════════════════════════════════════════════");
            lstUcuslar.Items.Add(string.Format("{0,-12} {1,-15} {2,-15} {3,-12} {4,-10} {5,-12} {6,-12}",
                "Uçuş No", "Kalkış", "Varış", "Tarih", "Saat", "Fiyat (₺)", "Boş Koltuk"));
            lstUcuslar.Items.Add("═══════════════════════════════════════════════════════════════════════════════════════");

            foreach (var ucus in bulunanUcuslar)
            {
                string satir = string.Format("{0,-12} {1,-15} {2,-15} {3,-12} {4,-10} {5,-12} {6,-12}",
                    ucus.UcusNo,
                    ucus.KalkisYeri.Length > 14 ? ucus.KalkisYeri.Substring(0, 14) : ucus.KalkisYeri,
                    ucus.VarisYeri.Length > 14 ? ucus.VarisYeri.Substring(0, 14) : ucus.VarisYeri,
                    ucus.KalkisTarihi.ToString("dd.MM.yyyy"),
                    ucus.KalkisSaati.ToString(@"hh\:mm"),
                    ucus.TemelFiyat.ToString("0"),
                    $"{ucus.Ucak.GetBosKoltukSayisi()}/{ucus.Ucak.ToplamKapasite}"
                );
                lstUcuslar.Items.Add(satir);
            }

            lstUcuslar.Items.Add("═══════════════════════════════════════════════════════════════════════════════════════");
            lstUcuslar.Items.Add("💡 İpucu: Uçuşa çift tıklayarak detayları görüntüleyebilirsiniz.");
        }

        // ListBox seçim değiştiğinde
        private void LstUcuslar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstUcuslar.SelectedIndex < 3 || lstUcuslar.SelectedItem == null)
            {
                btnDevam.Enabled = false;
                return;
            }

            string seciliSatir = lstUcuslar.SelectedItem.ToString();
            if (seciliSatir.Contains("═") || seciliSatir.Contains("Uçuş No") ||
                seciliSatir.Contains("İpucu") || seciliSatir.Contains("Üzgünüz"))
            {
                btnDevam.Enabled = false;
                return;
            }

            btnDevam.Enabled = true;
        }

        // Çift tıklama - Detay göster
        private void LstUcuslar_DoubleClick(object sender, EventArgs e)
        {
            if (lstUcuslar.SelectedItem == null) return;

            string seciliSatir = lstUcuslar.SelectedItem.ToString();
            if (seciliSatir.Contains("═") || seciliSatir.Contains("Uçuş No") ||
                seciliSatir.Contains("İpucu") || seciliSatir.Contains("Üzgünüz"))
                return;

            // Uçuş no'yu al
            string ucusNo = seciliSatir.Substring(0, 12).Trim();
            var ucus = bulunanUcuslar.FirstOrDefault(u => u.UcusNo == ucusNo);

            if (ucus != null)
            {
                MessageBox.Show(ucus.GetDetayliBilgi(), "Uçuş Detayları",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Devam butonu
        private void BtnDevam_Click(object sender, EventArgs e)
        {
            if (lstUcuslar.SelectedItem == null || lstUcuslar.SelectedIndex < 3)
            {
                MessageBox.Show("Lütfen bir uçuş seçiniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string seciliSatir = lstUcuslar.SelectedItem.ToString();
            string ucusNo = seciliSatir.Substring(0, 12).Trim();
            var seciliUcus = bulunanUcuslar.FirstOrDefault(u => u.UcusNo == ucusNo);

            if (seciliUcus != null)
            {
                // Koltuk seçim formuna git
                KoltukSecimForm koltukSecimForm = new KoltukSecimForm(musteri, seciliUcus);
                if (koltukSecimForm.ShowDialog() == DialogResult.OK)
                {
                    MessageBox.Show("Rezervasyonunuz tamamlandı! Müşteri paneline dönüyorsunuz.",
                        "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
        }

        // Geri butonu
        private void BtnGeri_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ListBox selection changed event'ini bağla
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            lstUcuslar.SelectedIndexChanged += LstUcuslar_SelectedIndexChanged;
        }

        private void UcusAramaForm_Load(object sender, EventArgs e)
        {

        }
    }
}