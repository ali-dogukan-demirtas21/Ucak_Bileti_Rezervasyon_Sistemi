﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;
using UcakRezervasyonSistemi.Utils;

namespace UcakRezervasyonSistemi
{
    public partial class KoltukSecimForm : Form
    {
        private Musteri musteri;
        private Ucus ucus;
        private RezervasyonServisi rezervasyonServisi;
        private FiyatlandirmaServisi fiyatlandirmaServisi;
        private Koltuk seciliKoltuk;

        // Kontroller
        private Label lblBaslik;
        private Label lblUcusBilgi;
        private Panel pnlKoltuklar;
        private Panel pnlBilgi;
        private Label lblSecimBaslik;
        private Label lblSeciliKoltuk;
        private Label lblFiyat;
        private Label lblYolcuBaslik;
        private Label lblYolcuAd;
        private TextBox txtYolcuAd;
        private Label lblYolcuSoyad;
        private TextBox txtYolcuSoyad;
        private Label lblYolcuTc;
        private TextBox txtYolcuTc;
        private Button btnRezervasyon;
        private Button btnIptal;
        private Panel pnlLegend;

        public KoltukSecimForm(Musteri musteri, Ucus ucus)
        {
            InitializeComponent();
            this.musteri = musteri;
            this.ucus = ucus;
            rezervasyonServisi = new RezervasyonServisi();
            fiyatlandirmaServisi = new FiyatlandirmaServisi();

            // Form ayarları
            this.Text = "Koltuk Seçimi";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.WhiteSmoke;
            this.AutoScroll = true;

            KontrolleriOlustur();
            KoltuklariOlustur();
        }

        private void KontrolleriOlustur()
        {
            // Başlık
            lblBaslik = new Label
            {
                Text = "KOLTUK SEÇİMİ",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(400, 15),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            this.Controls.Add(lblBaslik);

            // Uçuş Bilgisi
            lblUcusBilgi = new Label
            {
                Text = $"Uçuş: {ucus.UcusNo} | {ucus.KalkisYeri} → {ucus.VarisYeri} | {ucus.KalkisTarihi:dd.MM.yyyy} {ucus.KalkisSaati}",
                Font = new Font("Arial", 11),
                Location = new Point(30, 50),
                AutoSize = true,
                ForeColor = Color.DarkGreen
            };
            this.Controls.Add(lblUcusBilgi);

            // Legend (Açıklama) Paneli
            pnlLegend = new Panel
            {
                Location = new Point(30, 80),
                Size = new Size(940, 40),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.Add(pnlLegend);

            Label lblBoş = new Label
            {
                Text = "⬜ Boş",
                Location = new Point(20, 10),
                AutoSize = true,
                Font = new Font("Arial", 10),
                ForeColor = Color.Green
            };
            pnlLegend.Controls.Add(lblBoş);

            Label lblDolu = new Label
            {
                Text = "🟥 Dolu",
                Location = new Point(120, 10),
                AutoSize = true,
                Font = new Font("Arial", 10),
                ForeColor = Color.Red
            };
            pnlLegend.Controls.Add(lblDolu);

            Label lblSecili = new Label
            {
                Text = "🟦 Seçiminiz",
                Location = new Point(220, 10),
                AutoSize = true,
                Font = new Font("Arial", 10),
                ForeColor = Color.Blue
            };
            pnlLegend.Controls.Add(lblSecili);

            Label lblEkonomi = new Label
            {
                Text = "Ekonomi | Business | First Class",
                Location = new Point(380, 10),
                AutoSize = true,
                Font = new Font("Arial", 10, FontStyle.Italic),
                ForeColor = Color.Gray
            };
            pnlLegend.Controls.Add(lblEkonomi);

            // Koltuklar Paneli
            pnlKoltuklar = new Panel
            {
                Location = new Point(30, 130),
                Size = new Size(580, 510),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AutoScroll = true
            };
            this.Controls.Add(pnlKoltuklar);

            // Bilgi Paneli
            pnlBilgi = new Panel
            {
                Location = new Point(630, 130),
                Size = new Size(340, 510),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.Add(pnlBilgi);

            // Seçim Başlık
            lblSecimBaslik = new Label
            {
                Text = "SEÇİLEN KOLTUK",
                Font = new Font("Arial", 12, FontStyle.Bold),
                Location = new Point(20, 15),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            pnlBilgi.Controls.Add(lblSecimBaslik);

            // Seçili Koltuk
            lblSeciliKoltuk = new Label
            {
                Text = "Henüz koltuk seçilmedi",
                Font = new Font("Arial", 11),
                Location = new Point(20, 45),
                Size = new Size(300, 30),
                ForeColor = Color.Gray
            };
            pnlBilgi.Controls.Add(lblSeciliKoltuk);

            // Fiyat
            lblFiyat = new Label
            {
                Text = "Fiyat: -",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 80),
                AutoSize = true,
                ForeColor = Color.Green
            };
            pnlBilgi.Controls.Add(lblFiyat);

            // Yolcu Bilgileri Başlık
            lblYolcuBaslik = new Label
            {
                Text = "YOLCU BİLGİLERİ",
                Font = new Font("Arial", 12, FontStyle.Bold),
                Location = new Point(20, 125),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };
            pnlBilgi.Controls.Add(lblYolcuBaslik);

            int yPos = 160;

            // Yolcu Ad
            lblYolcuAd = new Label
            {
                Text = "Ad:",
                Location = new Point(20, yPos),
                Size = new Size(80, 20)
            };
            pnlBilgi.Controls.Add(lblYolcuAd);

            txtYolcuAd = new TextBox
            {
                Location = new Point(100, yPos),
                Size = new Size(220, 25),
                Font = new Font("Arial", 10),
                Text = musteri.Ad
            };
            pnlBilgi.Controls.Add(txtYolcuAd);
            yPos += 35;

            // Yolcu Soyad
            lblYolcuSoyad = new Label
            {
                Text = "Soyad:",
                Location = new Point(20, yPos),
                Size = new Size(80, 20)
            };
            pnlBilgi.Controls.Add(lblYolcuSoyad);

            txtYolcuSoyad = new TextBox
            {
                Location = new Point(100, yPos),
                Size = new Size(220, 25),
                Font = new Font("Arial", 10),
                Text = musteri.Soyad
            };
            pnlBilgi.Controls.Add(txtYolcuSoyad);
            yPos += 35;

            // Yolcu TC
            lblYolcuTc = new Label
            {
                Text = "TC No:",
                Location = new Point(20, yPos),
                Size = new Size(80, 20)
            };
            pnlBilgi.Controls.Add(lblYolcuTc);

            txtYolcuTc = new TextBox
            {
                Location = new Point(100, yPos),
                Size = new Size(220, 25),
                Font = new Font("Arial", 10),
                MaxLength = 11,
                Text = musteri.TcNo
            };
            pnlBilgi.Controls.Add(txtYolcuTc);

            // Rezervasyon Yap Butonu
            btnRezervasyon = new Button
            {
                Text = "Rezervasyon Yap",
                Location = new Point(20, 420),
                Size = new Size(300, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 11, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Enabled = false
            };
            btnRezervasyon.Click += BtnRezervasyon_Click;
            pnlBilgi.Controls.Add(btnRezervasyon);

            // İptal Butonu
            btnIptal = new Button
            {
                Text = "İptal",
                Location = new Point(20, 465),
                Size = new Size(300, 35),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnIptal.Click += BtnIptal_Click;
            pnlBilgi.Controls.Add(btnIptal);
        }

        private void KoltuklariOlustur()
        {
            int x = 20;
            int y = 20;
            int koltukGenislik = 45;
            int koltukYukseklik = 35;
            int bosluk = 5;
            int koridorGenislik = 30;

            // Koltukları sınıflarına göre grupla
            var firstClass = ucus.Ucak.Koltuklar.Where(k => k.Tip == KoltukTipi.FirstClass).ToList();
            var business = ucus.Ucak.Koltuklar.Where(k => k.Tip == KoltukTipi.Business).ToList();
            var ekonomi = ucus.Ucak.Koltuklar.Where(k => k.Tip == KoltukTipi.Ekonomi).ToList();

            // First Class
            if (firstClass.Count > 0)
            {
                Label lblFirst = new Label
                {
                    Text = "── FIRST CLASS ──",
                    Location = new Point(x, y),
                    Size = new Size(500, 20),
                    Font = new Font("Arial", 10, FontStyle.Bold),
                    ForeColor = Color.DarkGoldenrod,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                pnlKoltuklar.Controls.Add(lblFirst);
                y += 30;

                y = KoltukSirasiOlustur(firstClass, x, y, koltukGenislik, koltukYukseklik, bosluk, koridorGenislik, 4);
                y += 20;
            }

            // Business Class
            if (business.Count > 0)
            {
                Label lblBusiness = new Label
                {
                    Text = "── BUSINESS CLASS ──",
                    Location = new Point(x, y),
                    Size = new Size(500, 20),
                    Font = new Font("Arial", 10, FontStyle.Bold),
                    ForeColor = Color.DarkBlue,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                pnlKoltuklar.Controls.Add(lblBusiness);
                y += 30;

                y = KoltukSirasiOlustur(business, x, y, koltukGenislik, koltukYukseklik, bosluk, koridorGenislik, 4);
                y += 20;
            }

            // Ekonomi Class
            if (ekonomi.Count > 0)
            {
                Label lblEkonomi = new Label
                {
                    Text = "── EKONOMİ CLASS ──",
                    Location = new Point(x, y),
                    Size = new Size(500, 20),
                    Font = new Font("Arial", 10, FontStyle.Bold),
                    ForeColor = Color.DarkGreen,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                pnlKoltuklar.Controls.Add(lblEkonomi);
                y += 30;

                y = KoltukSirasiOlustur(ekonomi, x, y, koltukGenislik, koltukYukseklik, bosluk, koridorGenislik, 6);
            }
        }

        private int KoltukSirasiOlustur(List<Koltuk> koltuklar, int baslangicX, int baslangicY,
                                        int genislik, int yukseklik, int bosluk, int koridor, int sutunSayisi)
        {
            int x = baslangicX;
            int y = baslangicY;
            int sayac = 0;

            foreach (var koltuk in koltuklar)
            {
                Button btnKoltuk = new Button
                {
                    Text = koltuk.KoltukNo,
                    Size = new Size(genislik, yukseklik),
                    Location = new Point(x, y),
                    Font = new Font("Arial", 8, FontStyle.Bold),
                    Tag = koltuk,
                    Cursor = Cursors.Hand,
                    FlatStyle = FlatStyle.Flat
                };

                // Koltuk durumuna göre renk
                if (koltuk.Durum == KoltukDurumu.Dolu)
                {
                    btnKoltuk.BackColor = Color.IndianRed;
                    btnKoltuk.ForeColor = Color.White;
                    btnKoltuk.Enabled = false;
                }
                else
                {
                    btnKoltuk.BackColor = Color.LightGreen;
                    btnKoltuk.ForeColor = Color.Black;
                    btnKoltuk.Click += BtnKoltuk_Click;
                }

                pnlKoltuklar.Controls.Add(btnKoltuk);

                sayac++;
                x += genislik + bosluk;

                // Koridor ekle (ortada)
                if (sayac == sutunSayisi / 2)
                {
                    x += koridor;
                }

                // Yeni satır
                if (sayac == sutunSayisi)
                {
                    sayac = 0;
                    x = baslangicX;
                    y += yukseklik + bosluk;
                }
            }

            // Son satır tamamlanmadıysa bir satır daha ekle
            if (sayac != 0)
            {
                y += yukseklik + bosluk;
            }

            return y;
        }

        private void BtnKoltuk_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Koltuk koltuk = (Koltuk)btn.Tag;

            // Önceki seçimi temizle
            if (seciliKoltuk != null)
            {
                foreach (Control ctrl in pnlKoltuklar.Controls)
                {
                    if (ctrl is Button btnEski && btnEski.Tag == seciliKoltuk)
                    {
                        btnEski.BackColor = Color.LightGreen;
                        break;
                    }
                }
            }

            // Yeni seçim
            seciliKoltuk = koltuk;
            btn.BackColor = Color.LightBlue;

            // Fiyat hesapla
            decimal fiyat = fiyatlandirmaServisi.FiyatHesapla(ucus, koltuk.Tip);

            // Bilgileri güncelle
            lblSeciliKoltuk.Text = $"Koltuk: {koltuk.KoltukNo} ({koltuk.Tip})";
            lblSeciliKoltuk.ForeColor = Color.Black;
            lblFiyat.Text = $"Fiyat: {fiyat:C}";
            btnRezervasyon.Enabled = true;
        }

        private void BtnRezervasyon_Click(object sender, EventArgs e)
        {
            // Validasyon
            if (seciliKoltuk == null)
            {
                MessageBox.Show("Lütfen bir koltuk seçiniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtYolcuAd.Text) ||
                string.IsNullOrWhiteSpace(txtYolcuSoyad.Text) ||
                string.IsNullOrWhiteSpace(txtYolcuTc.Text))
            {
                MessageBox.Show("Lütfen yolcu bilgilerini eksiksiz doldurunuz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (txtYolcuTc.Text.Length != 11)
            {
                MessageBox.Show("TC Kimlik No 11 haneli olmalıdır!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtYolcuTc.Focus();
                return;
            }

            // Onay
            decimal fiyat = fiyatlandirmaServisi.FiyatHesapla(ucus, seciliKoltuk.Tip);
            var result = MessageBox.Show(
                $"Rezervasyon Özeti:\n\n" +
                $"Uçuş: {ucus.UcusNo}\n" +
                $"Rota: {ucus.KalkisYeri} → {ucus.VarisYeri}\n" +
                $"Tarih: {ucus.KalkisTarihi:dd.MM.yyyy} {ucus.KalkisSaati}\n" +
                $"Koltuk: {seciliKoltuk.KoltukNo} ({seciliKoltuk.Tip})\n" +
                $"Yolcu: {txtYolcuAd.Text} {txtYolcuSoyad.Text}\n" +
                $"Fiyat: {fiyat:C}\n\n" +
                $"Rezervasyonu onaylıyor musunuz?",
                "Rezervasyon Onayı",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    // Yolcu oluştur
                    var yolcu = new Yolcu(
                        0,
                        txtYolcuAd.Text.Trim(),
                        txtYolcuSoyad.Text.Trim(),
                        txtYolcuTc.Text.Trim(),
                        DateTime.Now.AddYears(-30), // Varsayılan doğum tarihi
                        "Belirtilmedi",
                        musteri.TelefonNo
                    );

                    // Rezervasyon oluştur
                    string rezervasyonNo = rezervasyonServisi.RezervasyonOlustur(
                        musteri.Id,
                        yolcu,
                        ucus.UcusNo,
                        seciliKoltuk.KoltukNo
                    );

                    if (rezervasyonNo != null)
                    {
                        MessageBox.Show(
                            $"Rezervasyonunuz başarıyla oluşturuldu!\n\n" +
                            $"Rezervasyon No: {rezervasyonNo}\n" +
                            $"Toplam Tutar: {fiyat:C}\n\n" +
                            $"İyi uçuşlar dileriz!",
                            "Başarılı",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Rezervasyon oluşturulamadı! Seçili koltuk dolu olabilir.",
                            "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Rezervasyon sırasında hata: {ex.Message}",
                        "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnIptal_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
