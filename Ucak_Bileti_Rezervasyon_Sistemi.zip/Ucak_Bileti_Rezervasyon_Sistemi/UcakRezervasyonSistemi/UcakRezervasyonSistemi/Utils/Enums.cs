﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UcakRezervasyonSistemi.Utils
{
    // Koltuk tipleri
    public enum KoltukTipi
    {
        Ekonomi,
        Business,
        FirstClass
    }

    // Koltuk durumu
    public enum KoltukDurumu
    {
        Bos,
        Dolu,
        Secili
    }

    // Kullanıcı rolleri
    public enum KullaniciRolu
    {
        Musteri,
        Admin
    }

    // Rezervasyon durumu
    public enum RezervasyonDurumu
    {
        Aktif,
        IptalEdildi,
        Tamamlandi
    }
}
