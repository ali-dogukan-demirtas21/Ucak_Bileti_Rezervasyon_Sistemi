﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;

namespace UcakRezervasyonSistemi
{
    public partial class KayitForm : Form
    {
        private KimlikDogrulamaServisi kimlikServisi;

        // Kontroller
        private Label lblBaslik;
        private Label lblAd;
        private TextBox txtAd;
        private Label lblSoyad;
        private TextBox txtSoyad;
        private Label lblTcNo;
        private TextBox txtTcNo;
        private Label lblEmail;
        private TextBox txtEmail;
        private Label lblTelefon;
        private TextBox txtTelefon;
        private Label lblSifre;
        private TextBox txtSifre;
        private Label lblSifreTekrar;
        private TextBox txtSifreTekrar;
        private Button btnKaydet;
        private Button btnIptal;

        public KayitForm()
        {
            InitializeComponent();
            kimlikServisi = new KimlikDogrulamaServisi();

            // Form ayarları
            this.Text = "Müşteri Kaydı";
            this.Size = new Size(450, 550);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            KontrolleriOlustur();
        }

        private void KontrolleriOlustur()
        {
            int x = 50;
            int y = 30;
            int labelGenislik = 120;
            int kontrolGenislik = 250;

            // Başlık
            lblBaslik = new Label
            {
                Text = "MÜŞTERİ KAYDI",
                Font = new Font("Arial", 16, FontStyle.Bold),
                Location = new Point(120, y),
                AutoSize = true
            };
            this.Controls.Add(lblBaslik);
            y += 50;

            // Ad
            lblAd = new Label
            {
                Text = "Ad:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblAd);

            txtAd = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtAd);
            y += 40;

            // Soyad
            lblSoyad = new Label
            {
                Text = "Soyad:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblSoyad);

            txtSoyad = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtSoyad);
            y += 40;

            // TC No
            lblTcNo = new Label
            {
                Text = "TC Kimlik No:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblTcNo);

            txtTcNo = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10),
                MaxLength = 11
            };
            this.Controls.Add(txtTcNo);
            y += 40;

            // Email
            lblEmail = new Label
            {
                Text = "Email:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblEmail);

            txtEmail = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10)
            };
            this.Controls.Add(txtEmail);
            y += 40;

            // Telefon
            lblTelefon = new Label
            {
                Text = "Telefon:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblTelefon);

            txtTelefon = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10),
                MaxLength = 11
            };
            this.Controls.Add(txtTelefon);
            y += 40;

            // Şifre
            lblSifre = new Label
            {
                Text = "Şifre:",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblSifre);

            txtSifre = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10),
                PasswordChar = '*'
            };
            this.Controls.Add(txtSifre);
            y += 40;

            // Şifre Tekrar
            lblSifreTekrar = new Label
            {
                Text = "Şifre (Tekrar):",
                Location = new Point(x, y),
                Size = new Size(labelGenislik, 20)
            };
            this.Controls.Add(lblSifreTekrar);

            txtSifreTekrar = new TextBox
            {
                Location = new Point(x + labelGenislik, y),
                Size = new Size(kontrolGenislik, 25),
                Font = new Font("Arial", 10),
                PasswordChar = '*'
            };
            this.Controls.Add(txtSifreTekrar);
            y += 60;

            // Kaydet Butonu
            btnKaydet = new Button
            {
                Text = "Kayıt Ol",
                Location = new Point(x + 20, y),
                Size = new Size(140, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnKaydet.Click += BtnKaydet_Click;
            this.Controls.Add(btnKaydet);

            // İptal Butonu
            btnIptal = new Button
            {
                Text = "İptal",
                Location = new Point(x + 180, y),
                Size = new Size(140, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnIptal.Click += BtnIptal_Click;
            this.Controls.Add(btnIptal);
        }

        // Kaydet butonu
        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            // Validasyon
            if (string.IsNullOrWhiteSpace(txtAd.Text))
            {
                MessageBox.Show("Lütfen adınızı giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAd.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtSoyad.Text))
            {
                MessageBox.Show("Lütfen soyadınızı giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoyad.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTcNo.Text) || txtTcNo.Text.Length != 11)
            {
                MessageBox.Show("Lütfen geçerli bir TC Kimlik No giriniz (11 hane)!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTcNo.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text) || !txtEmail.Text.Contains("@"))
            {
                MessageBox.Show("Lütfen geçerli bir email adresi giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTelefon.Text) || txtTelefon.Text.Length < 10)
            {
                MessageBox.Show("Lütfen geçerli bir telefon numarası giriniz!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTelefon.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtSifre.Text) || txtSifre.Text.Length < 6)
            {
                MessageBox.Show("Şifreniz en az 6 karakter olmalıdır!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSifre.Focus();
                return;
            }

            if (txtSifre.Text != txtSifreTekrar.Text)
            {
                MessageBox.Show("Şifreler eşleşmiyor!", "Uyarı",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSifreTekrar.Focus();
                return;
            }

            // Email kontrolü
            if (kimlikServisi.EmailKayitliMi(txtEmail.Text.Trim()))
            {
                MessageBox.Show("Bu email adresi zaten kayıtlı!", "Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return;
            }

            // TC No kontrolü
            if (kimlikServisi.TcNoKayitliMi(txtTcNo.Text.Trim()))
            {
                MessageBox.Show("Bu TC Kimlik No zaten kayıtlı!", "Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTcNo.Focus();
                return;
            }

            try
            {
                // Müşteri oluştur
                var musteri = new Musteri(
                    0, // ID otomatik atanacak
                    txtAd.Text.Trim(),
                    txtSoyad.Text.Trim(),
                    txtEmail.Text.Trim(),
                    txtSifre.Text,
                    txtTelefon.Text.Trim(),
                    txtTcNo.Text.Trim()
                );

                // Müşteriyi kaydet
                bool basarili = kimlikServisi.MusteriKaydet(musteri);

                if (basarili)
                {
                    MessageBox.Show("Kayıt başarılı! Şimdi giriş yapabilirsiniz.", "Başarılı",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Kayıt sırasında bir hata oluştu!", "Hata",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Kayıt sırasında hata: {ex.Message}", "Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // İptal butonu
        private void BtnIptal_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}