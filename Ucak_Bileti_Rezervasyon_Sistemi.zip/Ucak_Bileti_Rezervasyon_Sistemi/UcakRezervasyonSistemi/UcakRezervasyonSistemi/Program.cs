﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using UcakRezervasyonSistemi.Models;
using UcakRezervasyonSistemi.Services;

namespace UcakRezervasyonSistemi
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // İlk kurulum - Admin ve örnek veriler
            IlkKurulum();

            Application.Run(new LoginForm());
        }

        // İlk kurulum için admin ve örnek veriler oluştur
        static void IlkKurulum()
        {
            try
            {
                var kimlikServisi = new KimlikDogrulamaServisi();
                var ucusServisi = new UcusServisi();

                // Admin yoksa oluştur
                if (!kimlikServisi.EmailKayitliMi("admin@ucak.com"))
                {
                    var admin = new Admin(
                        0,
                        "Admin",
                        "Yönetici",
                        "admin@ucak.com",
                        "admin123",
                        "5551234567",
                        "Sistem Yöneticisi"
                    );

                    kimlikServisi.AdminKaydet(admin);
                }

                // Örnek uçuşlar oluştur
                ucusServisi.OrnekUcuslarOlustur();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"İlk kurulum hatası: {ex.Message}", "Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}